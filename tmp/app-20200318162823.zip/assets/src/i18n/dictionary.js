export default {
  en: {
    helloWorld: 'Hello World',
  },
};
